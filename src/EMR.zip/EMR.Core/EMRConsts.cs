﻿namespace EMR
{
    public class EMRConsts
    {
        public const string LocalizationSourceName = "EMR";
    }
}