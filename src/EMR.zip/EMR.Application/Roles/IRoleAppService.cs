﻿using System.Threading.Tasks;
using Abp.Application.Services;
using EMR.Roles.Dto;

namespace EMR.Roles
{
    public interface IRoleAppService : IApplicationService
    {
        Task UpdateRolePermissions(UpdateRolePermissionsInput input);
    }
}
