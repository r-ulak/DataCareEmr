require('./js/angular-daterangepicker.js');
module.exports = 'daterangepicker'
