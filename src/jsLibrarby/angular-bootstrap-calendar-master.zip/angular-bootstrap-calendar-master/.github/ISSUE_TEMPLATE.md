<!---
The github issues tracker is for bug reports and feature requests _ONLY_. Please use stackoverflow or read the documentation and examples for support issues, as well as checking previous issues.

Issues that ignore this template will be closed without notice!
-->
### Bug description / Feature request:


### Link to minimally-working plunker that reproduces the issue (starter template: http://plnkr.co/edit/LE4F4U7AnnD3tjM9ZH4G?p=preview)


### Versions

Angular: 

Calendar library: 

Browser name and version: 
