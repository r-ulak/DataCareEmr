angular.module('testModule3', ['testModule2']);
