require('./angulartics');
module.exports = 'angulartics';
